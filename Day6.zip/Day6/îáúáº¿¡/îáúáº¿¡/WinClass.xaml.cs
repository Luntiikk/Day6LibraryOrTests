﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WSUniversalLib;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для WinClass.xaml
    /// </summary>
    public partial class WinClass : Window
    {
        public WinClass()
        {
            InitializeComponent();
        }


        private void btQestions_Click(object sender, RoutedEventArgs e)
        {
            MaterialCalculator calculator = new MaterialCalculator();
            double totalMat = calculator.Calculation(Convert.ToInt32(tbCountProduct.Text), Convert.ToDouble(tbWidth.Text),
                Convert.ToDouble(tbLenght.Text), Convert.ToInt32(tbTypeProduct.Text), Convert.ToInt32(tbTypeMaterial.Text));
            tbAnswers.Text ="Ответ: " + totalMat;
        }
    }
}
