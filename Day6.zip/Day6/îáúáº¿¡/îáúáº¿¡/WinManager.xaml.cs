﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Магазин.DB;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для WinManager.xaml
    /// </summary>
    public partial class WinManager : Window
    {
        private Product[] products;
        private int totalCount;
        private int currentCount;
        public WinManager(DB.User user)
        {
            InitializeComponent();
            RefreshData();
            lbFullName.Content = user.UserSurname + " " +
                user.UserName + " " + user.UserPatronymic;
        }
        private Product[] SortProduct(Product[] product)//сортировка
        {
            try
            {
                if (cmbSort.SelectedIndex == 0)
                    product = product.ToArray();
                if (cmbSort.SelectedIndex == 1)
                    product = product.OrderBy(c => c.Price).ToArray();//по возрастанию
                if (cmbSort.SelectedIndex == 2)
                    product = product.
                        OrderByDescending(c => c.Price).ToArray();//по убыванию
            }
            catch { }
            return product;
        }

        private Product[] FilterProduct(Product[] product)//фильтрация
        {
            try
            {
                if (cmbFilt.SelectedIndex == 0)
                    product = product.ToArray();
                if (cmbFilt.SelectedIndex == 1)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "БТК Текстиль").ToArray();
                if (cmbFilt.SelectedIndex == 2)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Империя ткани").ToArray();
                if (cmbFilt.SelectedIndex == 3)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Комильфо").ToArray();
                if (cmbFilt.SelectedIndex == 4)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Май Фабрик").ToArray();
            }
            catch { }
            return product;
        }
        private Product[] SearchProduct(Product[] product)//поиск
        {
            try
            {
                if (tbSearch.Text != null)
                {
                    product = product.Where(c => c.ProductName.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                    c.ProductArticleNumber.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                     c.Description.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                     c.Manufactured.ManufacturedName.ToLower().
                    Contains(tbSearch.Text.ToLower())).ToArray();
                }
                if (product.Length == 0)
                {
                    ListProduct.ItemsSource = product;
                    MessageBox.Show("Товаров с таким данными не найдено");
                }
            }
            catch { }

            return product;
        }
        private void RefreshData()//метод для вывода данных 
        {

            products = App.trade.Products.ToArray();
            products = SortProduct(products);
            products = FilterProduct(products);
            products = SearchProduct(products);
            ListProduct.ItemsSource = products.ToList();
            totalCount = App.trade.Products.Count();
            currentCount = products.Count();
            countService.Content = $"{currentCount} / {totalCount}";
        }


        private void cmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshData();
        }

        private void cmbFilt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void btExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
