﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSUniversalLib
{
    public class MaterialCalculator
    {
        public double Calculation(int count, double width, double length, int productType, int materialType)
        {
            double area = width * length;
            double coefficient = 1.0;

            switch (productType)
            {
                case 1:
                    coefficient = 1.1;
                    break;
                case 2:
                    coefficient = 2.5;
                    break;
                case 3:
                    coefficient = 8.43;
                    break;
                default:
                    return -1;
            }

            double materialPercentage = 0.0;

            switch (materialType)
            {
                case 1:
                    materialPercentage = 0.003;
                    break;
                case 2:
                    materialPercentage = 0.0012;
                    break;
                default:
                    return -1;
            }

            double totalMaterial = count * area * coefficient * (materialPercentage);

            return totalMaterial;
        }
    }

}
