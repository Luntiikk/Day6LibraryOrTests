﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WSUniversalLib;


namespace UnitTestLibrary
{
    [TestClass]
    public class UnitTestLibrary
    {
        [TestMethod]
        public void GetQuantityForProduct_NegativeCount()
        {
            int productType = 2;
            int materialType = 1;
            int count = -10;
            double width = 10;
            double length = 10;
            double expected = -2507.5;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_NegativeLegth()
        {
            int productType = 2;
            int materialType = 1;
            int count = 10;
            double width = 10;
            double length = -10;
            double expected = -2507.5;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonExistentProductType()
        {
            int productType = 5;
            int materialType = 1;
            int count = 10;
            double width = 10;
            double length = 10;
            double expected = -1;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width, 
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetQuantityForProduct_TheSameValues()
        {
            int productType1 = 2;
            int materialType1 = 1;
            int count1 = 10;
            float width1 = 10;
            float length1 = 10;

            int productType2 = 2;
            int materialType2 = 1;
            int count2 = 10;
            float width2 = 10;
            float length2 = 10;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count1, width1,
                length1, productType1, materialType1);
            double actual1 = calculation.Calculation(count2, width2,
                length2, productType2, materialType2);

            Assert.AreEqual(actual, actual1);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonExistentMaterialType()
        {
            int productType = 2;
            int materialType = 4;
            int count = 10;
            double width = 10;
            double length = 10;
            double expected = -1;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_NegativeWidth()
        {
            int productType = 2;
            int materialType = 1;
            int count = 10;
            double width = -10;
            double length = -10;
            double expected = 2507.5;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetQuantityForProduct_Return100120()
        {
            int productType = 2;
            int materialType = 2;
            int count = 20;
            double width = 40;
            double length = 50;
            double expected = 100120;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_Return4413()
        {
            int productType = 1;
            int materialType = 1;
            int count = 20;
            float width = 10;
            float length = 20;
            double expected = 4413.2;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonExistentProductTypeAndMaterialType()
        {
            int productType = 5;
            int materialType = 3;
            int count = 10;
            float width = 10;
            float length = 10;
            double expected = -1;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_NegativeWidthAndLength()
        {
            int productType = 2;
            int materialType = 1;
            int count = 10;
            float width = -10;
            float length = -10;
            double expected = 2507.5;

            MaterialCalculator calculation = new MaterialCalculator();
            double actual = calculation.Calculation(count, width,
                length, productType, materialType);

            Assert.AreEqual(expected, actual);
        }

    }
}
